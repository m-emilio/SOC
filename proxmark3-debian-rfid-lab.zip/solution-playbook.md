# RFID Solution Playbook

## Legacy LF Credential Reliance

Risk: Legacy proximity card formats can leave access decisions dependent on
static identifiers or weak card data.

Preferred fixes:

- Migrate away from legacy LF-only credentials for sensitive areas.
- Disable fallback credential families after migration.
- Use authenticated credentials with per-site or per-application controls.
- Monitor for old credential formats during transition.

## UID-Only Or Static-Identifier Access Decisions

Risk: A reader/controller grants access based on data that is not
cryptographically authenticated.

Preferred fixes:

- Require mutual authentication.
- Use diversified keys and authenticated applications/files.
- Validate credential data at the controller, not only at the reader.
- Remove policies that treat UID/card serial as proof of identity.

## Weak Reader-Controller Transport

Risk: Reader output can be observed, replayed, modified, or spoofed between the
reader and controller.

Preferred fixes:

- Use OSDP Secure Channel or equivalent authenticated encryption.
- Avoid plain Wiegand for new deployments.
- Monitor reader tamper, disconnect, and bus faults.
- Place relays and unlock decisions inside the secure side.

## Revocation Delay

Risk: Removed users or badges continue to work because controller policy is
stale.

Preferred fixes:

- Define and test a revocation service-level objective.
- Alert when controllers miss policy updates.
- Validate offline behavior.
- Log denial reasons including revoked, expired, unknown, and wrong PIN.

## Keypad Or Multi-Factor Gaps

Risk: PINs are shared, default, guessable, or not rate-limited.

Preferred fixes:

- Disable default installer and shared codes.
- Use per-user PINs where possible.
- Enforce lockout, delay, and alerting.
- Review keypad logs during routine audits.

## Tamper And Power Handling

Risk: Reader removal, enclosure access, or power faults are not detected or
create unexpected access states.

Preferred fixes:

- Wire tamper switches to monitored inputs.
- Log reader disconnect and enclosure events.
- Test reader, controller, and lock-simulator power separately in the lab.
- Preserve code-compliant emergency egress in production.

## Logging Gaps

Risk: Operators cannot reconstruct access-control events after an incident.

Preferred fixes:

- Log timestamp, credential/user, reader, controller, decision, reason, and
  tamper/power state.
- Synchronize controller time.
- Protect logs from local overwrite.
- Include denied and malformed credential events.

## Egress Design Failure

Risk: Electronic access control can trap occupants.

Preferred fixes:

- Provide independent mechanical or marked emergency egress.
- Validate fail-safe/fail-secure choices with facilities and life-safety staff.
- Keep security controls from blocking emergency exit paths.
