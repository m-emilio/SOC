# RFID Lab Session Notes

## Session

- Date:
- Operator:
- Engagement or project:
- Debian version:
- Proxmark3 model:
- Proxmark3 client version:
- Proxmark3 firmware version:
- Upstream commit/release:

## Bench

- Reader/keypad:
- Controller:
- Dummy output:
- Power supply:
- Network isolation:
- Lab credential labels:

## Allowlisted Commands Used

- hw version:
- hw status:
- hw tune:
- lf search:
- hf search:

## Observations

| Time | Test ID | Expected | Actual | Evidence |
|---|---|---|---|---|
|  |  |  |  |  |

## Follow-Ups

- 
