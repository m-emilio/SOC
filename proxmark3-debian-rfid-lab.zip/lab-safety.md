# Lab Safety And Scope

## Allowed Scope

This lab is for defensive RFID research on isolated hardware:

- Owned Proxmark3 device.
- Owned lab LF/HF cards and tags.
- Owned reader/keypad hardware.
- Owned access controller or development controller.
- Dummy output such as an LED, buzzer, relay module, or unmounted strike.

## Out Of Scope

- Installed doors.
- Production building readers.
- Production access-control panels.
- Facility credentials.
- Building networks.
- Life-safety systems.
- Live clone, replay, unlock, or credential recovery procedures.

## Evidence Handling

Capture:

- Date and time.
- Operator.
- Debian version.
- Proxmark3 model.
- Client and firmware version.
- Upstream commit or release.
- Reader/controller models.
- Lab credential labels.
- Expected and actual results.

Keep raw dumps, keys, secrets, credential material, and sensitive captures in a
restricted evidence vault.

## Stop Conditions

Stop immediately if:

- A production card appears in the test set.
- Lab equipment is accidentally connected to a real facility system.
- The test could affect a life-safety function.
- Scope or ownership becomes unclear.
