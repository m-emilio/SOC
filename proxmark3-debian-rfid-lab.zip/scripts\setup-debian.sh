#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORKSPACE_DIR="$ROOT_DIR/workspace"
REPO_DIR="$WORKSPACE_DIR/proxmark3"

INSTALL_QT="${INSTALL_QT:-1}"
INSTALL_BLUETOOTH="${INSTALL_BLUETOOTH:-1}"
INSTALL_PYTHON="${INSTALL_PYTHON:-1}"
INSTALL_OPENCL="${INSTALL_OPENCL:-0}"

base_packages=(
  git
  ca-certificates
  build-essential
  pkg-config
  libreadline-dev
  gcc-arm-none-eabi
  libbz2-dev
  liblz4-dev
  zlib1g-dev
  libssl-dev
  libgd-dev
  usbutils
)

optional_packages=()

if [[ "$INSTALL_QT" == "1" ]]; then
  optional_packages+=(qt6-base-dev)
fi

if [[ "$INSTALL_BLUETOOTH" == "1" ]]; then
  optional_packages+=(libbluetooth-dev)
fi

if [[ "$INSTALL_PYTHON" == "1" ]]; then
  optional_packages+=(libpython3-dev python3)
fi

if [[ "$INSTALL_OPENCL" == "1" ]]; then
  optional_packages+=(ocl-icd-opencl-dev)
fi

printf '%s\n' "Installing Debian dependencies..."
sudo apt-get update

if ! sudo apt-get install --no-install-recommends -y \
  "${base_packages[@]}" libnewlib-dev "${optional_packages[@]}"; then
  printf '%s\n' "libnewlib-dev install failed; retrying with picolibc-arm-none-eabi for newer Debian branches..."
  sudo apt-get install --no-install-recommends -y \
    "${base_packages[@]}" picolibc-arm-none-eabi "${optional_packages[@]}"
fi

mkdir -p "$WORKSPACE_DIR" "$ROOT_DIR/logs"

if [[ -d "$REPO_DIR/.git" ]]; then
  printf '%s\n' "Updating existing Proxmark3 checkout..."
  git -C "$REPO_DIR" pull --ff-only
else
  printf '%s\n' "Cloning RfidResearchGroup/proxmark3..."
  git clone https://github.com/RfidResearchGroup/proxmark3.git "$REPO_DIR"
fi

cat <<'NEXT'

Setup complete.

Next:
  cd workspace/proxmark3
  make clean && make -j

For serial permissions:
  make accessrights

Then log out and back in before testing /dev/ttyACM0 access.
NEXT
