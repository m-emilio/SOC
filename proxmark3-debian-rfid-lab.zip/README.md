# Debian RFID Lab With Proxmark3

This pack recreates the earlier lab environment as a Debian-native RFID bench.
It is built around the RfidResearchGroup Proxmark3 repository:

https://github.com/RfidResearchGroup/proxmark3

Use it only with owned lab hardware, owned test cards/tags, and dummy outputs.
Do not connect it to production doors, facility readers, live access-control
controllers, building networks, or life-safety systems.

## What This Gives You

- Debian package setup for building the Proxmark3 client and firmware.
- USB/serial permission checks for `/dev/ttyACM0`.
- A clean workspace layout for LF and HF RFID lab work.
- A safe command allowlist for inventory and validation.
- A defensive RFID test matrix.
- A remediation playbook and finding template.

## Target Platform

- Debian 12 Bookworm or newer.
- Debian-derived research images such as Kali or Parrot should also work, but
  this pack names Debian as the baseline.
- Proxmark3 RDV4 defaults are supported by the upstream build. For generic or
  modified Proxmark3 hardware, read the upstream advanced compilation notes
  before flashing.

## Folder Layout

```text
proxmark3-debian-rfid-lab/
  scripts/
    debian-host-check.sh
    setup-debian.sh
    start-pm3-lab.sh
  templates/
    finding-template.md
    session-notes.md
    rfid-test-matrix.csv
  workspace/
    proxmark3/
  logs/
```

`workspace/proxmark3` is a normal clone of the upstream project. Keep raw
captures, credential material, and sensitive evidence out of the report body and
inside a restricted evidence store.

## Quick Start

From a Debian terminal:

```sh
cd proxmark3-debian-rfid-lab
./scripts/debian-host-check.sh
./scripts/setup-debian.sh
./scripts/start-pm3-lab.sh
```

Inside the Proxmark3 workspace:

```sh
make clean && make -j
```

The upstream project recommends keeping the Proxmark3 client and firmware from
the same source version. Avoid mixing a freshly built client with firmware from a
different checkout or release.

## First Hardware Check

After plugging in the lab Proxmark3:

```sh
ls -l /dev/ttyACM*
./scripts/start-pm3-lab.sh --client
```

If the device is visible but not readable/writable, run the permission helper
from the upstream repo:

```sh
cd workspace/proxmark3
make accessrights
```

Then log out and back in so group membership takes effect.

## Safe RFID Command Allowlist

Use only against owned lab tags/cards:

```text
hw version
hw status
hw tune
data clear
lf search
hf search
help
quit
```

This pack intentionally does not include clone, replay, credential recovery,
live-door, or production-reader procedures.

## RFID Lab Flow

1. Photograph the bench and label every reader, tag, card, controller, and dummy
   output.
2. Run host and USB checks.
3. Build from the upstream checkout.
4. Record Proxmark3 client/firmware version and upstream commit.
5. Inventory lab tags with `lf search` and `hf search`.
6. Exercise defensive tests from `templates/rfid-test-matrix.csv`.
7. Map failures to `solution-playbook.md`.
8. Write results with `templates/finding-template.md`.

## RFID Domains Covered

- LF RFID around 125 kHz and 134.2 kHz, including lab inventory and policy
  validation.
- HF RFID and NFC around 13.56 MHz, including lab inventory and configuration
  validation.
- Reader-controller transport review, tamper handling, revocation behavior,
  keypad policy, audit logging, and egress design.

## Included Files

- `scripts/debian-host-check.sh`: checks Debian version, required tools, USB
  device visibility, ModemManager state, and group membership.
- `scripts/setup-debian.sh`: installs Debian build dependencies, creates
  folders, and clones or updates the upstream repo.
- `scripts/start-pm3-lab.sh`: opens the repo workspace or starts the local
  Proxmark3 client when requested.
- `lab-safety.md`: scope and stop conditions.
- `hardware-bench.md`: safe RFID bench layout.
- `solution-playbook.md`: defensive fixes for common RFID access-control
  weaknesses.
- `templates/rfid-test-matrix.csv`: lab test tracker.
- `templates/finding-template.md`: report-ready finding skeleton.
- `templates/session-notes.md`: repeatable session notes.

## Upstream References

- Proxmark3 repository: https://github.com/RfidResearchGroup/proxmark3
- Linux installation: https://github.com/RfidResearchGroup/proxmark3/blob/master/doc/md/Installation_Instructions/Linux-Installation-Instructions.md
- Compilation: https://github.com/RfidResearchGroup/proxmark3/blob/master/doc/md/Use_of_Proxmark/0_Compilation-Instructions.md
- Docker reference: https://github.com/RfidResearchGroup/proxmark3/tree/master/docker
