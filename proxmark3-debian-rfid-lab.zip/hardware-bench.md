# RFID Bench Hardware

## Minimum Bench

- Debian laptop or workstation.
- Proxmark3.
- LF lab tags, if testing low-frequency RFID.
- HF lab cards/tags, if testing high-frequency RFID or NFC.
- Reader/keypad under test.
- Access controller or development controller.
- Dummy output: LED, buzzer, relay module, or unmounted strike.
- Current-limited bench power supply.
- Multimeter.
- Optional logic analyzer.
- Optional isolated Ethernet switch for IP-connected lab controllers.

## Layout

```text
LF/HF lab tag <-> Proxmark3
LF/HF lab tag <-> reader/keypad -> controller -> dummy output
                                      |
                                      +-> isolated admin workstation or switch
```

No component in this layout should control a real door.

## LF RFID Notes

LF systems are often used for legacy proximity badges. In a defensive lab, the
main questions are:

- Does production policy still permit legacy credential families?
- Are card numbers treated as sufficient proof of identity?
- Are unknown or malformed lab tags denied and logged?
- Is migration to stronger credentials planned and tracked?

## HF RFID And NFC Notes

HF/NFC systems vary widely. In a defensive lab, document:

- Credential family.
- Whether mutual authentication is required.
- Whether diversified keys or authenticated applications are used.
- Whether fallback or compatibility modes are enabled.
- Whether revocation and audit logging behave correctly.

## Reader-Controller Path

Document what connects the reader to the controller:

- Wiegand or clock/data.
- OSDP without secure channel.
- OSDP Secure Channel.
- Vendor serial.
- IP-connected reader/controller.

Prefer authenticated and encrypted reader-controller transport, and keep access
decisions and relays on the secure side of the opening.
