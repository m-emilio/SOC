#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_DIR="$ROOT_DIR/workspace/proxmark3"
DEVICE="${PM3_DEVICE:-/dev/ttyACM0}"

if [[ ! -d "$REPO_DIR" ]]; then
  printf '%s\n' "Proxmark3 repo is missing. Run ./scripts/setup-debian.sh first."
  exit 1
fi

case "${1:-}" in
  --client)
    if [[ ! -e "$DEVICE" ]]; then
      printf '%s\n' "Device $DEVICE not found. Set PM3_DEVICE or plug in the lab Proxmark3."
      exit 1
    fi

    if [[ -x "$REPO_DIR/client/proxmark3" ]]; then
      cd "$REPO_DIR"
      exec "$REPO_DIR/client/proxmark3" "$DEVICE"
    fi

    printf '%s\n' "Client binary not found. Build first with: cd workspace/proxmark3 && make clean && make -j"
    exit 1
    ;;
  --build)
    cd "$REPO_DIR"
    make clean
    exec make -j"$(nproc)"
    ;;
  *)
    cat <<INFO
Debian RFID lab workspace:
  $REPO_DIR

Common next steps:
  cd "$REPO_DIR"
  make clean && make -j
  ./pm3

Or:
  $0 --build
  $0 --client

Current PM3_DEVICE:
  $DEVICE
INFO
    ;;
esac
