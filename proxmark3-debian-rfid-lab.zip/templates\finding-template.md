# Finding: <Short Title>

## Summary

<Describe the RFID weakness and the affected lab configuration in one
paragraph.>

## Scope

- Environment: isolated Debian RFID lab bench
- Debian version:
- Tooling: Proxmark3 client/firmware version <version>
- Upstream commit or release:
- Proxmark3 hardware:
- Reader/keypad:
- Controller:
- Credentials: lab-only test tags/cards <labels>
- Output: dummy relay/LED/bench strike, not a live door

## Impact

<Explain what the weakness would mean in a production deployment. Avoid
step-by-step bypass procedures.>

## Evidence

- Test case IDs:
- Date/time:
- Expected result:
- Actual result:
- Screenshots/logs:
- Photos:
- Restricted evidence reference:

## Root Cause

<Configuration issue, legacy RFID technology, static identifier dependency,
unauthenticated reader transport, weak policy, missing tamper handling, or other
cause.>

## Recommended Remediation

<Tailor fixes from solution-playbook.md.>

## Retest Plan

<List specific lab tests to repeat after remediation.>

## Sensitive Appendix

Keep raw credential material, captures, keys, and sensitive reproducer details
in a restricted evidence vault rather than the general report body.
