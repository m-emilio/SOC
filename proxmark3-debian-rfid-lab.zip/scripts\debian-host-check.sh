#!/usr/bin/env bash
set -euo pipefail

say() {
  printf '%s\n' "$*"
}

ok() {
  say "[ok] $*"
}

warn() {
  say "[warn] $*"
}

missing() {
  say "[missing] $*"
}

say "Checking Debian host..."

if [[ -r /etc/os-release ]]; then
  # shellcheck disable=SC1091
  . /etc/os-release
  say "OS: ${PRETTY_NAME:-unknown}"
else
  warn "/etc/os-release not found"
fi

for cmd in git make gcc pkg-config python3 sudo lsusb dmesg; do
  if command -v "$cmd" >/dev/null 2>&1; then
    ok "$cmd found at $(command -v "$cmd")"
  else
    missing "$cmd"
  fi
done

say ""
say "Checking Proxmark3 USB visibility..."
if compgen -G "/dev/ttyACM*" >/dev/null; then
  ls -l /dev/ttyACM*
else
  warn "No /dev/ttyACM* devices found. Plug in the lab Proxmark3 and retry."
fi

if command -v lsusb >/dev/null 2>&1; then
  say ""
  say "Nearby USB devices mentioning proxmark, PM3, or CDC:"
  lsusb | grep -Ei 'proxmark|pm3|cdc|openmoko' || warn "No obvious Proxmark3 USB line found."
fi

say ""
say "Checking serial group membership..."
if id -nG "$USER" | tr ' ' '\n' | grep -Eq '^(dialout|uucp)$'; then
  ok "$USER is in a common serial-access group"
else
  warn "$USER is not in dialout/uucp. After cloning, run: cd workspace/proxmark3 && make accessrights"
fi

say ""
say "Checking ModemManager..."
if systemctl list-unit-files 2>/dev/null | grep -q '^ModemManager.service'; then
  if systemctl is-active --quiet ModemManager.service; then
    warn "ModemManager is active. Upstream Proxmark3 docs warn it can interfere with the device."
  else
    ok "ModemManager is installed but not active"
  fi
else
  ok "ModemManager service not found"
fi

say ""
say "Host check complete."
